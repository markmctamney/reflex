# e2e-tests-blocks

End-to-end testing for the Blocks library using Cypress.

To run tests:

```sh
yarn workspace e2e-tests-blocks test:e2e
```

To run CI tests:

```sh
yarn workspace e2e-tests-blocks test:e2e:ci
```
