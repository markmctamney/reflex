export default {
  colors: {
    background: "#f94",
  },
}
