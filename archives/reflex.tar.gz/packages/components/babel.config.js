module.exports = require("../../babel.config")
