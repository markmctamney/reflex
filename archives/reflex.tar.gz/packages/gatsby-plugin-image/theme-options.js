module.exports = (themeOptions) => ({
  imagesPath: `content/images`,
  ...themeOptions,
})
