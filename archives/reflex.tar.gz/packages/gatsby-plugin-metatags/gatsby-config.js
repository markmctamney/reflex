module.exports = {
  plugins: [`@reflexjs/gatsby-plugin-image`, `gatsby-plugin-react-helmet`],
}
