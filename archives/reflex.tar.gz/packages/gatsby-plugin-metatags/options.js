module.exports = (options) => ({
  debug: false,
  global: {},
  types: [],
  paths: [],
  ...options,
})
