import * as React from "react"

export const SearchContext = React.createContext(null)
