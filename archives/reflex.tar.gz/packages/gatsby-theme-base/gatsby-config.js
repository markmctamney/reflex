module.exports = () => {
  return {
    plugins: [
      `@reflexjs/gatsby-plugin-metatags`,
      `@reflexjs/gatsby-plugin-image`,
      `@reflexjs/gatsby-theme-core`,
      `@reflexjs/gatsby-theme-block`,
      `@reflexjs/gatsby-theme-nav`,
    ],
  }
}
