import theme from "../../theme"
export default theme
