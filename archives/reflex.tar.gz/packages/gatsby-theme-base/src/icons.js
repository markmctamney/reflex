import icons from "@reflexjs/icons-feather"

export default {
  ...icons,
}
