// FIXME: Figure out why this breaks when merge import is removed.
// eslint-disable-next-line no-unused-vars
import { merge } from "@reflexjs/gatsby-theme-core"
import base from "@reflexjs/preset-base"

export default {
  preset: base,
}
