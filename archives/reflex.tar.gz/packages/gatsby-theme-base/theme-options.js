module.exports = (themeOptions) => ({
  ...themeOptions,
})
