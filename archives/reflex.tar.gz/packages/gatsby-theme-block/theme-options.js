module.exports = (themeOptions) => ({
  contentPath: "content/blocks",
  ...themeOptions,
})
