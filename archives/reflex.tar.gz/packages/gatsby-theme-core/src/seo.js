import * as React from "react"

// DEPRECATED.
export const Seo = ({ pathname }) => null
