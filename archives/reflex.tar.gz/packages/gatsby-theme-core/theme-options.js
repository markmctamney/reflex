module.exports = (themeOptions) => ({
  contentPath: `content/pages`,
  basePath: ``,
  mdxRemarkPlugins: [],
  gatsbyRemarkPlugins: [],
  remarkPlugins: [],
  ...themeOptions,
})
