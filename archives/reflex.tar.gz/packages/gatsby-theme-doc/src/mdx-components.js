import { Callout } from "./callout"

export const MDXComponents = {
  Callout,
}
