module.exports = (themeOptions) => ({
  contentPath: "content/docs",
  basePath: "/docs",
  ...themeOptions,
})
