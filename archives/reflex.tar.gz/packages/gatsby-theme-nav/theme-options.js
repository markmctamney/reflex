module.exports = (themeOptions) => ({
  contentPath: "content/navs",
  ...themeOptions,
})
