module.exports = (themeOptions) => ({
  contentPath: "content/profiles",
  basePath: "/users",
  ...themeOptions,
})
