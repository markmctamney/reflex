module.exports = (themeOptions) => ({
  contentPath: "styleguide",
  basePath: "/styleguide",
  ...themeOptions,
})
