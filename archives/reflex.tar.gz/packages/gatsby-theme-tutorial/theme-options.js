module.exports = (themeOptions) => ({
  contentPath: "tutorial",
  basePath: "/learn",
  ...themeOptions,
})
