import icons from "./icons/feathericons.json"

export default icons
