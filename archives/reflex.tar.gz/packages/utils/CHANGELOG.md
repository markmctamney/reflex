# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.2.1](https://github.com/reflexjs/reflex/compare/@reflexjs/utils@0.2.0...@reflexjs/utils@0.2.1) (2020-07-13)

**Note:** Version bump only for package @reflexjs/utils





# [0.2.0](https://github.com/reflexjs/reflex/compare/@reflexjs/utils@0.1.3...@reflexjs/utils@0.2.0) (2020-07-04)


### Features

* **metatags:** add gatsby-plugin-metatags and gatsby-plugin-image ([7dd35ca](https://github.com/reflexjs/reflex/commit/7dd35ca5a88f686f11a0f3772d4eaaa640842ba9))





## [0.1.3](https://github.com/reflexjs/reflex/compare/@reflexjs/utils@0.1.2...@reflexjs/utils@0.1.3) (2020-06-18)

**Note:** Version bump only for package @reflexjs/utils





## [0.1.2](https://github.com/reflexjs/reflex/compare/@reflexjs/utils@0.1.1...@reflexjs/utils@0.1.2) (2020-06-18)

**Note:** Version bump only for package @reflexjs/utils





## [0.1.1](https://github.com/reflexjs/reflex/compare/@reflexjs/utils@0.1.0...@reflexjs/utils@0.1.1) (2020-06-18)

**Note:** Version bump only for package @reflexjs/utils





# 0.1.0 (2020-06-18)


### Features

* initial commit ([27540b0](https://github.com/reflexjs/reflex/commit/27540b022a849212a21894b05df928e5e6b19456))
