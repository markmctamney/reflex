import base from "@reflexjs/preset-base"

export default {
  preset: base,
}
