module.exports = [
  {
    name: "Header",
  },
  {
    name: "Hero",
    display: "grid",
  },
  {
    name: "Features",
    display: "grid",
  },
  {
    name: "Call To Action",
    display: "grid",
  },
  {
    name: "Forms",
    display: "grid",
  },
  {
    name: "Pricing",
    display: "grid",
  },
  {
    name: "Team",
    display: "grid",
  },
  {
    name: "Testimonials",
    display: "grid",
  },
  {
    name: "Cards",
    display: "grid",
  },
  {
    name: "Posts",
    display: "grid",
  },
  {
    name: "Videos",
    display: "grid",
  },
  {
    name: "Footer",
  },
]
